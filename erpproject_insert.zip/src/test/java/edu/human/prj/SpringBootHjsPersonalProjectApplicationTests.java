package edu.human.prj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHjsPersonalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
