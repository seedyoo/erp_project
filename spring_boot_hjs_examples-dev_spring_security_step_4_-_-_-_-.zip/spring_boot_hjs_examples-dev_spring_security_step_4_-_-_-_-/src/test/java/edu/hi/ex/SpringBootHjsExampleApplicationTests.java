package edu.hi.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHjsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
